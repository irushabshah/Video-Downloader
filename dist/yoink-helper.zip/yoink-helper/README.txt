Yoink helper 0.2.0

The Yoink extension uses this small helper to download videos on your computer.
You need Node.js 18 or newer: https://nodejs.org
On a Mac you also need Homebrew: https://brew.sh

Mac or Linux:
  1. Open Terminal in this folder.
  2. Run: ./scripts/install.sh

Windows:
  1. Open PowerShell in this folder.
  2. Run: powershell -ExecutionPolicy Bypass -File scripts\install.ps1

Then open the Yoink popup in Chrome and press "Check again".
To remove the helper, run the same script with --uninstall (Mac, Linux) or -Uninstall (Windows).
